---
name: webrtc-screen-sharing
description: WebRTC 无线投屏系统开发经验 - Windows 本地开发 + RK3588 硬件部署
---

# WebRTC 无线投屏系统 - 开发经验 Skill

## 项目概述

基于 WebRTC 的无线投屏接收器，用于 RK3588 硬件部署。支持浏览器发起投屏，接收端通过 GStreamer 解码并显示。

**技术栈：**
- 后端：Python + aiohttp + GStreamer
- 前端：原生 JavaScript + WebRTC API
- 信令：WHEP (RFC 9372) + WebSocket 兼容
- 硬件加速：MPP decode + RGA scale + DRM/KMS display

**当前状态：** Windows 本地开发环境，10/10 功能测试通过，准备 RK3588 移植。

---

## 核心架构

```
browser (sender)              receiver (RK3588)
    |                              |
    |-- getUserMedia ----->     webrtcbin
    |                              |
    |-- WebRTC SDP ----->      gst-launch
    |                              |
    |-- ICE candidates -->    mpp/rga/drm
                                  |
                               HDMI/LCD
```

**后端模块：**
- `backend/server.py` - HTTP/WebSocket 服务器，WHEP 信令端点
- `backend/signaling_server.py` - 独立信令服务器（备用）
- `gst/receiver.py` - WebRTC 接收器，管理 GStreamer 管线
- `gst/compositor.py` - 多路视频合成
- `gst/audio_mixer.py` - 音频混音
- `mdns_service.py` - mDNS 设备发现

**前端模块：**
- `frontend/sender.html` - 投屏发送端
- `frontend/view.html` - 观看端
- `frontend/dashboard.html` - 状态控制面板

---

## 开发经验总结

### 1. 静态文件路由

**问题：** aiohttp 静态文件路由，lambda 函数返回 404

**错误代码：**
```python
app.router.add_get("/sender.html", lambda r: web.FileResponse(FRONTEND_DIR / "sender.html"))
```

**解决方案：** 使用 async 函数替代 lambda
```python
async def sender_html_handler(request):
    sender_path = FRONTEND_DIR / "sender.html"
    if sender_path.exists():
        return web.FileResponse(sender_path)
    return web.Response(text="Sender page not found", status=404)

app.router.add_get("/sender.html", sender_html_handler)
```

**原因：** aiohttp 路由处理器需要协程函数，lambda 可能不被正确识别。

---

### 2. WebSocket 超时参数

**问题：** `websockets.connect()` 不支持 `timeout` 参数
```python
async with websockets.connect("ws://localhost:8080/ws", timeout=5) as ws:
```

**解决方案：** 使用 `asyncio.wait_for()`
```python
async with websockets.connect("ws://localhost:8080/ws") as ws:
    await asyncio.wait_for(ws.recv(), timeout=5.0)
```

---

### 3. Windows 控制台编码

**问题：** emoji 字符在 Windows 控制台显示为乱码

**解决方案：** 使用纯文本标记
```python
# 坏: print("[✅] Test passed")
# 好: print("[PASS] Test passed")
```

---

### 4. 设备发现 (mDNS)

**实现：**
- `mdns_service.py` - 使用 zeroconf 库
- 自动广播服务到局域网
- 前端自动发现并列出可用设备

**注意：** Windows 开发环境可能没有 zeroconf，需要容错处理：
```python
try:
    from zeroconf import ServiceInfo, Zeroconf
except ImportError:
    logger.warning("zeroconf 未安装，mDNS 功能不可用")
```

---

### 5. GStreamer WebRTC 关键点

**SDP 交换：**
```python
# 接收端生成 Answer
def set_offer(self, offer):
    # 需要在 GLib 主线程中运行
    self.webrtc.set_property("signaling-state", WebRTCSignalingState.STABLE)
    self.webrtc.emit("signal-on-ice-candidate", ...)
    return self.answer_sdp
```

**ICE 候选：**
```python
def add_ice_candidate(self, candidate, sdp_mid, sdp_mline_index):
    # 必须在 signaling-state == STABLE 后添加
    self.webrtc.emit("add-ice-candidate", ...)
```

---

### 6. 连接稳定性

**重连策略：** 指数退避
```javascript
class ReconnectManager {
    constructor() {
        this.retryCount = 0;
        this.baseDelay = 1000;
        this.maxDelay = 30000;
    }

    getDelay() {
        const delay = Math.min(this.baseDelay * Math.pow(2, this.retryCount), this.maxDelay);
        this.retryCount++;
        return delay;
    }
}
```

---

## 测试方法

### 本地功能测试
```bash
# 启动服务器
cd backend
python server.py

# 运行测试（另一个终端）
python test/local_test_simple.py
```

**测试覆盖：**
- HTTP API: `/health`, `/info`, `/api/status`, `/api/discover`
- WebSocket: 主信令端点 + 终端端点
- 静态文件: 所有前端页面

**预期结果：** 10/10 tests passing

---

## RK3588 移植要点

### 依赖安装
```bash
# 硬件编解码器
apt-get install gstreamer1.0-rockchip1

# DRM/KMS 显示
apt-get install libdrm-dev

# mDNS
pip3 install zeroconf
```

### GStreamer 管线差异
```bash
# Windows (软件解码)
... ! vp8dec ! ...

# RK3588 (硬件解码)
... ! rkmppdec ! ...
```

### 显示输出
```bash
# Windows (测试用)
... ! autovideosink

# RK3588 (HDMI 输出)
... ! rkmppdec ! kmssink
```

---

## 当前文件结构

```
video_test/
├── backend/
│   ├── server.py              # 主服务器（推荐）
│   ├── signaling_server.py    # 独立信令服务器
│   ├── config.py              # 配置文件
│   └── mdns_service.py        # mDNS 服务
├── gst/
│   ├── receiver.py            # WebRTC 接收器
│   ├── compositor.py          # 视频合成
│   └── audio_mixer.py         # 音频混音
├── frontend/
│   ├── sender.html            # 投屏发送端
│   ├── view.html              # 观看端
│   ├── dashboard.html         # 控制面板
│   └── error-handler.js       # 统一错误处理
├── test/
│   └── local_test_simple.py   # 本地功能测试
└── skills/
    └── webrtc-screen-sharing.md  # 本文件
```

---

## 更新日志

### 2026-04-27
- ✅ Windows 本地环境 10/10 测试通过
- ✅ 静态文件路由修复
- ✅ WebSocket 连接测试通过
- ✅ HTTP API 完整验证

### 下一步
- [ ] RK3588 硬件移植
- [ ] 硬件加速解码测试
- [ ] DRM/KMS 显示输出
- [ ] 性能优化

---

## 使用此 Skill

**导入新环境：**
1. 将 `skills/` 目录复制到新项目
2. 在对话中引用：`/webrtc-screen-sharing`

**更新进展：**
- 直接编辑本文件
- 记录遇到的问题和解决方案
- 更新"下一步"清单

**保持同步：**
- 每次重大修改后更新"更新日志"
- 记录环境差异（Windows vs Linux）
- 保存配置变更
