# WebRTC 硬件设备接收端 - 开发指南

## 架构说明

```
┌─────────┐         ┌─────────────┐         ┌──────────────┐
│  PC A   │         │             │         │              │
│ (浏览器) │ ────>  │  信令服务器  │ ────>  │ 硬件设备     │
└─────────┘         │ (WebSocket) │         │ (接收端)      │
                    └─────────────┘         │  - 显示      │
┌─────────┐                                   │  - 存储      │
│  PC B   │ ──────────────────────────────>  │  - 转发      │
│ (浏览器) │                                   │  - 分析      │
└─────────┘                                   └──────────────┘
```

## 当前实现

**浏览器端（已完成）：**
- ✅ 屏幕捕获（getDisplayMedia）
- ✅ WebRTC P2P 传输
- ✅ 信令服务器（Python + websockets）
- ✅ 实时视频流传输

**硬件接收端（开发中）：**
- 🔨 WebSocket 信令通信
- 🔨 WebRTC 握手协议
- 🔨 H.264 视频流接收
- 🔨 视频解码和处理

## 硬件部署方案

### 方案 1：嵌入式 Linux（推荐）

**硬件要求：**
- CPU: ARM Cortex-A53 或更好
- RAM: 512MB+
- 网络: 以太网或 WiFi
- 系统: Linux (Ubuntu Core, Yocto, Buildroot)

**软件栈：**
```
应用层: Python/C++ 接收端应用
      ↓
媒体层: GStreamer (硬件加速解码)
      ↓
显示层: DRM/KMS (直接显示) 或 HDMI 输出
      ↓
存储: 本地存储或网络转发
```

**快速开始：**
```bash
# 安装依赖
sudo apt install python3-pip gstreamer1.0-tools gstreamer1.0-plugins-good

# 安装 Python 库
pip install websockets av gstreamer-python

# 运行接收端
python3 hardware_receiver.py --session <session_id>
```

### 方案 2：树莓派（低成本原型）

**硬件：**
- 树莓派 4 (4GB+ 推荐)
- 官方 Raspberry Pi OS

**优势：**
- 低成本（~$50-70）
- 社区支持好
- 支持 GStreamer 硬件加速
- 适合快速原型验证

**安装步骤：**
```bash
# 启用硬件加速
sudo raspi-config
# 选择: Interface Options → GL Driver → GL (Fake KMS)

# 安装 GStreamer 和 Python 库
sudo apt update
sudo apt install python3-pip gstreamer1.0-tools \
    gstreamer1.0-plugins-base \
    gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-bad \
    gstreamer1.0-libav

pip3 install websockets av
```

### 方案 3：Windows 设备

**适用场景：**
- 工业 PC
- Windows IoT 设备
- NUC 迷你电脑

**安装：**
```powershell
# 安装 Python
# 下载 GStreamer Windows 运行时
# https://gstreamer.freedesktop.org/download/

pip install websockets pyav
python hardware_receiver.py --session <session_id>
```

## 视频处理选项

### 选项 1：实时显示（最简单）

```python
# 使用 GStreamer 管道实时显示
pipeline = "appsrc ! videoconvert ! autovideosink"
```

### 选项 2：保存为文件

```python
# 保存为 MP4 文件
pipeline = "appsrc ! videoconvert ! avimux ! filesink location=output.mp4"
```

### 选项 3：转发到其他服务

```python
# 转发到 RTMP 服务器
pipeline = "appsrc ! x264enc ! flvmux ! rtmpsink location=rtmp://server/live/stream"
```

### 选项 4：视频分析

```python
# 使用 OpenCV 分析
import cv2
# 从 WebRTC 接收帧 → OpenCV 处理 → 结果输出
```

## 生产环境考虑

### 1. 性能优化

**视频编码参数：**
```javascript
// 发送端：优化编码参数
const videoConstraints = {
  video: {
    width: { ideal: 1920 },
    height: { ideal: 1080 },
    frameRate: { ideal: 30 },
    facingMode: 'user'
  }
};
```

**硬件加速解码：**
```bash
# 树莓派：使用 V4L2 硬件解码
GST_PLUGIN_PATH=/usr/lib/aarch64-linux-gnu/gstreamer-1.0
```

### 2. 可靠性

**自动重连机制：**
```python
async def auto_reconnect(session_id, max_retries=5):
    for attempt in range(max_retries):
        try:
            await connect_to_session(session_id)
            break
        except Exception as e:
            logger.error(f"连接失败: {e}, 重试 {attempt+1}/{max_retries}")
            await asyncio.sleep(5)
```

**心跳检测：**
```python
# 定期发送 ping 检测连接状态
async def heartbeat(ws):
    while True:
        try:
            await ws.ping()
            await asyncio.sleep(30)
        except:
            break
```

### 3. 安全性

**身份验证：**
```python
# 添加 token 验证
await ws.send(json.dumps({
    "type": "join_session",
    "session_id": session_id,
    "token": "your_secure_token"
}))
```

**加密传输：**
```python
# 使用 WSS (WebSocket Secure)
wss://your-server.com:8081
```

## 下一步开发方向

### 阶段 1：原型验证（当前）
- ✅ 浏览器发送端
- ✅ 信令服务器
- 🔨 Python 接收端原型

### 阶段 2：功能完善
- [ ] GStreamer 视频解码
- [ ] 文件保存功能
- [ ] 多会话管理
- [ ] 命令行控制

### 阶段 3：硬件适配
- [ ] 树莓派部署
- [ ] 硬件加速解码
- [ ] HDMI 输出显示
- [ ] 自动启动服务

### 阶段 4：产品化
- [ ] 设备管理界面
- [ ] 远程配置
- [ ] 日志和监控
- [ ] OTA 升级

## 测试方法

### 1. 本地测试
```bash
# 终端 1: 启动信令服务器
cd backend && python signaling_server.py

# 终端 2: 启动硬件接收端
cd hardware && python hardware_receiver.py --interactive

# 浏览器: 打开 sender.html 开始投屏
# 在接收端输入会话 ID 连接
```

### 2. 多会话测试
```python
# 同时监控多个会话
session_ids = ["ws_session1", "ws_session2", "ws_session3"]
await receiver.monitor_multiple_sessions(session_ids)
```

### 3. 性能测试
```bash
# 测试带宽使用
# 测试延迟
# 测试 CPU 占用
```

## 技术支持

### 常见问题

**Q: 视频卡顿**
A: 检查网络带宽，降低视频分辨率

**Q: 解码失败**
A: 确认 GStreamer 插件安装完整，特别是 H.264 解码器

**Q: 无法连接**
A: 检查防火墙设置，确认 WebSocket 端口开放

### 有用的命令

```bash
# 查看 GStreamer 版本
gst-launch-1.0 --version

# 列出所有 GStreamer 插件
gst-inspect-1.0

# 测试视频管道
gst-launch-1.0 videotestsrc ! autovideosink

# 监控系统资源
htop
```

## 资源链接

- GStreamer 官网: https://gstreamer.freedesktop.org/
- PyAV 文档: https://pyav.org/stable/
- 树莓派: https://www.raspberrypi.com/
- WebRTC 基础: https://webrtc.org/
