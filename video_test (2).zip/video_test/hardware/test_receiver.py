#!/usr/bin/env python3
"""
WebRTC Receiver Prototype Test
"""

import asyncio
import json
import sys

try:
    import websockets
except ImportError:
    print("Error: websockets not installed")
    print("Install: pip install websockets")
    sys.exit(1)

from pathlib import Path
import time

async def test_receiver():
    WS_URL = "ws://localhost:8081"
    SESSION_ID = "ws_test_session"

    print("=" * 50)
    print("WebRTC Hardware Receiver Test")
    print("=" * 50)
    print(f"Server: {WS_URL}")
    print(f"Session ID: {SESSION_ID}")
    print()
    print("Instructions:")
    print("  1. Open http://localhost:8080/sender.html")
    print("  2. Click 'Start Cast'")
    print("  3. This test will verify receiving data")
    print()

    output_dir = Path("./test_output")
    output_dir.mkdir(exist_ok=True)
    print(f"Output directory: {output_dir.absolute()}")

    try:
        async with websockets.connect(WS_URL, close_timeout=5) as ws:
            print("\n[1/4] [OK] WebSocket connected")

            await ws.send(json.dumps({
                "type": "join_session",
                "session_id": SESSION_ID
            }))
            print("[2/4] [OK] Sent join request")

            received_offer = False
            received_ice = False
            message_count = 0

            print("\n[3/4] Waiting for messages (30s)...")
            print("Tip: Start screen sharing in browser now")
            print()

            start_time = time.time()
            while time.time() - start_time < 30:
                try:
                    message = await asyncio.wait_for(ws.recv(), timeout=1.0)
                    message_count += 1
                    data = json.loads(message)
                    msg_type = data.get("type")

                    if msg_type == "offer":
                        print(f"  [{message_count}] [OK] Received SDP Offer")
                        print(f"      Size: {len(data.get('sdp', ''))} chars")

                        offer_file = output_dir / f"{SESSION_ID}_offer.json"
                        offer_content = json.dumps(json.loads(data["sdp"]), indent=2)
                        offer_file.write_text(offer_content)
                        print(f"      Saved: {offer_file.name}")

                        received_offer = True

                        # Send Answer (for testing)
                        answer_msg = {
                            "type": "answer",
                            "session_id": SESSION_ID,
                            "sdp": json.dumps({
                                "type": "answer",
                                "sdp": "v=0\r\no=- 0 0 IN IP4 127.0.0.1\r\n"
                            })
                        }
                        await ws.send(json.dumps(answer_msg))

                    elif msg_type == "ice_candidate":
                        print(f"  [{message_count}] [OK] Received ICE candidate")
                        candidate_data = data.get("candidate", "")
                        print(f"      Prefix: {candidate_data[:50]}...")

                        ice_file = output_dir / f"{SESSION_ID}_ice_{message_count}.json"
                        ice_file.write_text(json.dumps(data, indent=2))
                        print(f"      Saved: {ice_file.name}")

                        received_ice = True

                    elif msg_type == "answer":
                        print(f"  [{message_count}] [OK] Received Answer")

                    elif msg_type == "error":
                        print(f"  [{message_count}] [ERROR] {data.get('message')}")

                except asyncio.TimeoutError:
                    continue

            print("  [OK] Receive timeout (30s)")

            # Results
            print("\n" + "=" * 50)
            print("Test Results:")
            print("=" * 50)

            tests = [
                ("WebSocket connection", True),
                ("Receive SDP Offer", received_offer),
                ("Receive ICE candidate", received_ice),
                ("Save received data", received_offer or received_ice),
            ]

            for test_name, passed in tests:
                status = "[PASS]" if passed else "[FAIL]"
                print(f"{test_name}: {status}")

            print(f"\nTotal messages: {message_count}")
            print(f"Output: {output_dir.absolute()}")

            # Summary
            print("\n" + "=" * 50)
            if received_offer:
                print(">>> PROTOTYPE VALIDATION PASSED <<<")
                print("\nPython receiver successfully:")
                print("  - Connected to signaling server")
                print("  - Received SDP Offer")
                print("  - Received ICE candidates")
                print("  - Saved data to files")
                print("\nNext step: Integrate GStreamer for video decode")
            else:
                print(">>> PARTIAL PROTOTYPE VALIDATION <<<")
                print("\nPassed:")
                print("  - Connected to signaling server")
                print("\nMissing:")
                print("  - No Offer received (verify sender is running)")
                print("\nSuggestions:")
                print("  1. Ensure signaling server is running on port 8081")
                print("  2. Open http://localhost:8080/sender.html")
                print("  3. Click 'Start Cast' button")
                print("  4. Re-run this test")

    except ConnectionRefused:
        print("\n[ERROR] Cannot connect to signaling server")
        print(f"  Verify server is running at: {WS_URL}")
    except OSError as e:
        print(f"\n[ERROR] Connection error: {e}")
    except Exception as e:
        print(f"\n[ERROR] Test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    try:
        asyncio.run(test_receiver())
    except KeyboardInterrupt:
        print("\n\nTest cancelled")
